import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import socket
from PIL import Image as PILImage
import io

class LoginForm(toga.Box):
    def __init__(self, app):
        super().__init__(style=Pack(direction=COLUMN, padding=10))
        
        self.app = app

        self.email_or_name_input = toga.TextInput(placeholder='Email или ФИО')
        self.password_input = toga.PasswordInput(placeholder='Пароль')
        self.login_button = toga.Button('Войти', on_press=self.verify_credentials)
        self.error_label = toga.Label('', style=Pack(color='red'))

        self.add(self.email_or_name_input)
        self.add(self.password_input)
        self.add(self.login_button)
        self.add(self.error_label)
    
    def verify_credentials(self, widget):
        email_or_name = self.email_or_name_input.value
        password = self.password_input.value

        try:
            user_id = self.check_with_server(email_or_name, password)
            if user_id:
                self.app.main_window.content = QRScannerForm(self.app, user_id)
            else:
                self.error_label.text = "Пользователь не существует или неверный пароль"
        except ConnectionError as e:
            self.error_label.text = f"Ошибка подключения: {str(e)}"

    def check_with_server(self, email_or_name, password):
        host = '127.0.0.1'  # замените на IP адрес вашего сервера
        port = 65433

        try:
            client_socket = socket.socket()
            client_socket.connect((host, port))
            message = f"LOGIN,{email_or_name},{password}"
            client_socket.send(message.encode())
            response = client_socket.recv(1024).decode()
            client_socket.close()

            if response.startswith("SUCCESS"):
                return int(response.split(',')[1])
            else:
                return None
        except socket.error as e:
            raise ConnectionError("Не удалось подключиться к серверу") from e


class QRScannerForm(toga.Box):
    def __init__(self, app, user_id):
        super().__init__(style=Pack(direction=COLUMN, padding=10))
        
        self.app = app
        self.user_id = user_id

        self.video_view = toga.ImageView(style=Pack(flex=1))
        self.result_label = toga.Label('Нажмите кнопку для создания фото')
        self.capture_button = toga.Button('Сделать фото', on_press=self.capture_photo)

        self.add(self.video_view)
        self.add(self.result_label)
        self.add(self.capture_button)

    def capture_photo(self, widget):
        # Имитация захвата фото
        try:
            with open('path_to_your_image.png', 'rb') as image_file:
                image_data = image_file.read()
                self.video_view.image = toga.Image(data=image_data)
                self.result_label.text = "Фото сделано"
        except FileNotFoundError:
            self.result_label.text = "Не удалось найти изображение"

    def send_to_server(self, door_id, user_id):
        host = '127.0.0.1'
        port = 65433

        client_socket = socket.socket()
        client_socket.connect((host, port))
        message = f"{door_id},{user_id}"
        client_socket.send(message.encode())
        response = client_socket.recv(1024).decode()

        self.result_label.text = response
        client_socket.close()


class MyApp(toga.App):
    def startup(self):
        self.main_window = toga.MainWindow(title=self.formal_name)  # Используем formal_name

        login_form = LoginForm(self)
        self.main_window.content = login_form
        self.main_window.show()


def main():
    return MyApp('My App', 'org.beeware.myapp')


if __name__ == '__main__':
    main().main_loop()
