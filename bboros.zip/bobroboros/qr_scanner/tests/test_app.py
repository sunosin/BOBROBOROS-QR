def test_first():
    """An initial test for the app."""
    assert 1 + 1 == 2
