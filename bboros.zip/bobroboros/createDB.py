# populate_db.py
import sqlite3

def add_user(user_id, full_name, email, password, door_ids):
    conn = sqlite3.connect('access_control.db')
    cursor = conn.cursor()

    door_ids_str = ','.join(map(str, door_ids))
    cursor.execute('''
        INSERT INTO users (id, full_name, email, password, door_ids) 
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, full_name, email, password, door_ids_str))

    conn.commit()
    conn.close()

def main():
    add_user(1, 'Иван Иванов', 'ivan@example.com', 'password123', [1, 2])
    add_user(2, 'Мария Петрова', 'maria@example.com', 'securepass', [2, 3])
    add_user(3, 'Петр Сидоров', 'petr@example.com', 'mypassword', [1, 3, 4])

    print("Данные пользователей успешно добавлены в базу данных")

if __name__ == '__main__':
    main()
