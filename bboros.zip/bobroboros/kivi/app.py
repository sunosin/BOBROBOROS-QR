# main.py
import socket
import cv2
from pyzbar.pyzbar import decode
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.graphics.texture import Texture

class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super(LoginScreen, self).__init__(**kwargs)
        self.box = BoxLayout(orientation='vertical')

        self.email_or_name_input = TextInput(hint_text="Email или ФИО", multiline=False)
        self.password_input = TextInput(hint_text="Пароль", password=True, multiline=False)
        self.login_button = Button(text="Войти")
        self.login_button.bind(on_press=self.verify_credentials)
        self.error_label = Label(text="", color=(1, 0, 0, 1))

        self.box.add_widget(self.email_or_name_input)
        self.box.add_widget(self.password_input)
        self.box.add_widget(self.login_button)
        self.box.add_widget(self.error_label)

        self.add_widget(self.box)

    def verify_credentials(self, instance):
        email_or_name = self.email_or_name_input.text
        password = self.password_input.text

        user_id = self.check_with_server(email_or_name, password)
        if user_id:
            self.manager.current = 'qr_scan'
            self.manager.get_screen('qr_scan').user_id = user_id
        else:
            self.error_label.text = "Пользователь не существует или неверный пароль"

    def check_with_server(self, email_or_name, password):
        host = '127.0.0.1'  # замените на IP адрес вашего сервера
        port = 65433

        client_socket = socket.socket()
        client_socket.connect((host, port))
        message = f"LOGIN,{email_or_name},{password}"
        client_socket.send(message.encode())
        response = client_socket.recv(1024).decode()
        client_socket.close()

        if response.startswith("SUCCESS"):
            return int(response.split(',')[1])
        else:
            return None

class QRScannerScreen(Screen):
    def __init__(self, **kwargs):
        super(QRScannerScreen, self).__init__(**kwargs)
        self.capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Используем cv2.CAP_DSHOW для захвата видео
        self.box = BoxLayout(orientation='vertical')

        self.image = Image()
        self.box.add_widget(self.image)

        self.result_label = Label(text="Отсканируйте QR код")
        self.box.add_widget(self.result_label)

        self.decode_button = Button(text="Сканировать QR-код")
        self.decode_button.bind(on_press=self.scan_qr)
        self.box.add_widget(self.decode_button)

        Clock.schedule_interval(self.update_image, 1.0 / 30.0)
        self.add_widget(self.box)

    def update_image(self, dt):
        ret, frame = self.capture.read()
        if ret:
            buf = cv2.flip(frame, 0).tobytes()
            image_texture = Texture.create(size=(frame.shape[1], frame.shape[0]), colorfmt='bgr')
            image_texture.blit_buffer(buf, colorfmt='bgr', bufferfmt='ubyte')
            self.image.texture = image_texture

    def scan_qr(self, instance):
        ret, frame = self.capture.read()
        if ret:
            decoded_objects = decode(frame)
            for obj in decoded_objects:
                decoded_text = obj.data.decode('utf-8')
                try:
                    door_id = int(decoded_text)
                    user_id = self.user_id  # Используем ID пользователя, полученный при входе
                    self.send_to_server(door_id, user_id)
                except ValueError:
                    self.result_label.text = "Попробуйте еще раз"
                    Clock.schedule_once(self.reset_label, 5)

    def send_to_server(self, door_id, user_id):
        host = '127.0.0.1'
        port = 65433

        client_socket = socket.socket()
        client_socket.connect((host, port))
        message = f"{door_id},{user_id}"
        client_socket.send(message.encode())
        response = client_socket.recv(1024).decode()

        self.result_label.text = response

        Clock.schedule_once(self.reset_label, 5)

        client_socket.close()

    def reset_label(self, dt):
        self.result_label.text = "Отсканируйте QR код"

    def on_stop(self):
        self.capture.release()

class MainApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(QRScannerScreen(name='qr_scan'))
        return sm

if __name__ == '__main__':
    MainApp().run()
