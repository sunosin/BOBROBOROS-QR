# server.py
import socket
import sqlite3
import datetime
import asyncio

def create_tables():
    conn = sqlite3.connect('access_control.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            full_name TEXT,
            email TEXT,
            password TEXT,
            door_ids TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS log (
            door_id INTEGER,
            user_id INTEGER,
            timestamp TEXT
        )
    ''')

    conn.commit()
    conn.close()

def check_access(user_id, door_id):
    conn = sqlite3.connect('access_control.db')
    cursor = conn.cursor()

    cursor.execute('SELECT door_ids FROM users WHERE id=?', (user_id,))
    result = cursor.fetchone()

    if result:
        door_ids = result[0].split(',')
        if str(door_id) in door_ids:
            return "Открыто"
        else:
            return "Отказано в доступе"
    else:
        return "Пользователь не найден"

def log_access(user_id, door_id, status):
    conn = sqlite3.connect('access_control.db')
    cursor = conn.cursor()

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('INSERT INTO log (door_id, user_id, timestamp) VALUES (?, ?, ?)', (door_id, user_id, timestamp))

    conn.commit()
    conn.close()

def verify_user(email_or_name, password):
    conn = sqlite3.connect('access_control.db')
    cursor = conn.cursor()

    cursor.execute('SELECT id FROM users WHERE (email=? OR full_name=?) AND password=?', (email_or_name, email_or_name, password))
    user = cursor.fetchone()

    conn.close()
    if user:
        return user[0]  # Возвращаем ID пользователя
    else:
        return None

async def handle_client(reader, writer):
    addr = writer.get_extra_info('peername')
    print(f"Подключен к: {addr}")

    while True:
        data = await reader.read(100)
        message = data.decode()

        if not message:
            break

        print(f"Сообщение от клиента: {message}")
        parts = message.split(',')
        if parts[0] == 'LOGIN':
            email_or_name, password = parts[1], parts[2]
            print(f"Проверка учетных данных: {email_or_name}, {password}")
            user_id = verify_user(email_or_name, password)
            if user_id:
                status = f"SUCCESS,{user_id}"
                print(f"Успешный вход: {user_id}")
            else:
                status = "FAILURE"
                print("Неудачный вход")
        else:
            try:
                door_id, user_id = map(int, parts)
                print(f"Проверка доступа: user_id={user_id}, door_id={door_id}")
                status = check_access(user_id, door_id)
                log_access(user_id, door_id, status)
            except ValueError:
                status = "Попробуйте еще раз"
                print("Ошибка разбора сообщения")

        writer.write(status.encode())
        await writer.drain()

    writer.close()
    await writer.wait_closed()
    print(f"Отключен от: {addr}")

async def main():
    host = '127.0.0.1'
    port = 65433

    create_tables()

    server = await asyncio.start_server(handle_client, host, port)
    print(f"Сервер запущен и ожидает подключения на {host}:{port}")

    async with server:
        await server.serve_forever()

if __name__ == '__main__':
    asyncio.run(main())
