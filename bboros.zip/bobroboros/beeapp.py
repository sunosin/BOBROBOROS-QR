import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import socket
import cv2
from pyzbar.pyzbar import decode


class LoginForm(toga.Box):
    def __init__(self, app):
        super().__init__(style=Pack(direction=COLUMN, padding=10))
        
        self.app = app

        self.email_or_name_input = toga.TextInput(placeholder='Email или ФИО')
        self.password_input = toga.PasswordInput(placeholder='Пароль')
        self.login_button = toga.Button('Войти', on_press=self.verify_credentials)
        self.error_label = toga.Label('', style=Pack(color='red'))

        self.add(self.email_or_name_input)
        self.add(self.password_input)
        self.add(self.login_button)
        self.add(self.error_label)
    
    def verify_credentials(self, widget):
        email_or_name = self.email_or_name_input.value
        password = self.password_input.value

        user_id = self.check_with_server(email_or_name, password)
        if user_id:
            self.app.main_window.content = QRScannerForm(self.app, user_id)
        else:
            self.error_label.text = "Пользователь не существует или неверный пароль"

    def check_with_server(self, email_or_name, password):
        host = '127.0.0.1'  # замените на IP адрес вашего сервера
        port = 65433

        client_socket = socket.socket()
        client_socket.connect((host, port))
        message = f"LOGIN,{email_or_name},{password}"
        client_socket.send(message.encode())
        response = client_socket.recv(1024).decode()
        client_socket.close()

        if response.startswith("SUCCESS"):
            return int(response.split(',')[1])
        else:
            return None


class QRScannerForm(toga.Box):
    def __init__(self, app, user_id):
        super().__init__(style=Pack(direction=COLUMN, padding=10))
        
        self.app = app
        self.user_id = user_id
        self.capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Используем cv2.CAP_DSHOW для захвата видео

        self.result_label = toga.Label('Отсканируйте QR код')
        self.decode_button = toga.Button('Сканировать QR-код', on_press=self.scan_qr)
        self.add(self.result_label)
        self.add(self.decode_button)
    
    def scan_qr(self, widget):
        ret, frame = self.capture.read()
        if ret:
            decoded_objects = decode(frame)
            for obj in decoded_objects:
                decoded_text = obj.data.decode('utf-8')
                try:
                    door_id = int(decoded_text)
                    self.send_to_server(door_id, self.user_id)
                except ValueError:
                    self.result_label.text = "Попробуйте еще раз"

    def send_to_server(self, door_id, user_id):
        host = '127.0.0.1'
        port = 65433

        client_socket = socket.socket()
        client_socket.connect((host, port))
        message = f"{door_id},{user_id}"
        client_socket.send(message.encode())
        response = client_socket.recv(1024).decode()

        self.result_label.text = response
        client_socket.close()


class MyApp(toga.App):
    def startup(self):
        self.main_window = toga.MainWindow(title=self.name)

        login_form = LoginForm(self)
        self.main_window.content = login_form
        self.main_window.show()


def main():
    return MyApp('My App', 'org.beeware.myapp')


if __name__ == '__main__':
    main().main_loop()
