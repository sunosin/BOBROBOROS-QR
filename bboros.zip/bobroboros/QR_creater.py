import qrcode
import numpy as np

def generate_qr_matrix(data, scale=3):
    # Генерация QR-кода
    qr = qrcode.QRCode(border=1)
    qr.add_data(data)
    qr.make(fit=True)
    
    # Преобразование QR-кода в матрицу из нулей и единиц
    qr_matrix = np.array(qr.modules).astype(int)

    for i in qr.modules:
        print('[', end = '')
        d=0
        for j in i:
            if d < len(i)-1:
                print(int(j), end=', ')
            else:
                print(int(j), end='')

            d+=1
        print('],')
    
    return qr_matrix

# Пример использования
number = 5  # Заданное число
original_matrix = generate_qr_matrix(number)
